<template>
    <div class="home">
        <header class="header">
            <Header />
        </header>
        <aside>
            <SideBar />
        </aside>
        <main>
            <router-view />
        </main>
    </div>
</template>

<script setup lang="ts">
import Header from '@/layout/header/Header.vue'
import SideBar from '@/layout/SideBar.vue'


</script>

<style scoped>

</style>