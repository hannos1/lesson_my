<template>
    <div>
        SideBar
    </div>
</template>

<script setup lang="ts">

</script>

<style lang="stylus" scoped>

</style>