<template>
    <div>
        Home
        <router-view />
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>