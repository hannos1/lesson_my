<script setup lang="ts">
import {getBanners} from './service/recommend'
import {onMounted} from 'vue'

onMounted(async () => {
  const data = await getBanners()
  console.log(data)
})
</script>

<template>
<router-view />
</template>

<style scoped>

</style>
