<template>
    <tr>
        <th>Avatar</th>
        <th>Id</th>
        <th>Name</th>
    </tr>
</template>

<script setup lang="ts">

</script>

<style>

</style>